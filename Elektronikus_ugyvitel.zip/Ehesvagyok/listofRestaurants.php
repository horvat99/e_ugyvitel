<div class="container-fluid">
    <div class="row">
        <div class="col-12 text-center mt-5">
            <h2 class="pb-5">Elérhető éttermeink listája</h2>

            <table class="table table-striped">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Név</th>
                    <th scope="col">Város</th>
                    <th scope="col">Cím</th>
                </tr>
                </thead>
                <tbody>
                <?php
                include ("db_config.php");
                global $connection;
                $result = $connection->query("SELECT restaurants.restaurant_id, restaurants.name, restaurants.address, city.city 
                from restaurants JOIN city on restaurants.postcode = city.postcode order by restaurants.restaurant_id ASC");
                foreach ($result as $key => $value)
                {
                    echo '<tr>
                <th scope="row">'.$value['restaurant_id'].'</th>
                <td>'.$value['name'].'</td>
                <td>'.$value['city'].'</td>
                <td>'.$value['address'].'</td>
            </tr>';
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>


</div>