<?php
include("db_config.php");
include("config.php");
global $connection;
$username = $comment = "";

if (isset($_POST['username'])) {
    $username = strip_tags(trim($_POST['username']));
}
if (isset($_POST['comment'])) {
    $comment = strip_tags(trim($_POST['comment']));

$sql = "SELECT id_user FROM users WHERE username = '$username'";
$result = mysqli_query($connection, $sql) or die(mysqli_error($connection));
$row = mysqli_fetch_assoc($result);
$idUser = $row['id_user'];

$sql2 = "UPDATE orders SET comment = '$comment', status = '1' WHERE id_user = '$idUser' and status='0'";
    if (mysqli_query($connection, $sql2)) {
        echo "Sikeres hozzászóllás!";
    }

}