<?php
include("db_config.php");
include("config.php");
global $connection;
$username = "";

if (isset($_POST['username'])) {
    $username = strip_tags(trim($_POST['username']));

//$username = "asd";

$sql = "SELECT id_user FROM users WHERE username = '$username'";
$result = mysqli_query($connection, $sql) or die(mysqli_error($connection));
$row = mysqli_fetch_assoc($result);
$idUser = $row['id_user'];

$sql = "SELECT * FROM orders WHERE id_user = '$idUser' and status = '0' LIMIT 1";
$result = mysqli_query($connection, $sql) or die(mysqli_error($connection));
$row = mysqli_fetch_assoc($result);
if ($row){
$message = "Dátum: ".$row['date'] . "<br>Rendelési idő: ". $row['time'].
"<br>Érkezési idő: " . $row['timearrive']
. "<br>Étterem: " . $row['restaurant'] . "<br>Étel: " . $row['food']."<hr>";
echo $message;
}
/*else
    echo "Önnek nincs olyan rendelt étele amiről nem írt véleményt!";*/
}




