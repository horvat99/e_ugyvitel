window.addEventListener('load', function() {
    document.getElementById('login').addEventListener('submit', function(e) {
        if (checkForm()) this.submit();
        e.preventDefault();
    });


});
// this function is checking that every field is filled out, and if is not than error is shown above the field.
var checkForm = function() {
    document.getElementById('username_error').innerHTML = '';
    document.getElementById('password_error').innerHTML = '';



    var isValid = true;

    if (document.getElementById('username').value == '') {
        document.getElementById('username').style.borderColor = '#f00';
        document.getElementById('username_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('password').value == '') {
        document.getElementById('password').style.borderColor = '#f00';
        document.getElementById('password_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }


    return isValid;
}