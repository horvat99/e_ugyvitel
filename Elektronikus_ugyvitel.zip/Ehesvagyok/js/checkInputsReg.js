window.addEventListener('load', function() {
    document.getElementById('register').addEventListener('submit', function(e) {
        if (checkForm()) this.submit();
        e.preventDefault();
    });


});
// this function is checking that every field is filled out, and if is not than error is shown above the field.
var checkForm = function() {
    document.getElementById('firstname_error').innerHTML = '';
    document.getElementById('lastname_error').innerHTML = '';
    document.getElementById('city_error').innerHTML = '';
    document.getElementById('adress_error').innerHTML = '';
    document.getElementById('phone_error').innerHTML = '';
    document.getElementById('email_error').innerHTML = '';
    document.getElementById('username_error').innerHTML = '';
    document.getElementById('password_error').innerHTML = '';
    document.getElementById('password_ver_error').innerHTML = '';
    document.getElementById('captcha_error').innerHTML = '';



    var isValid = true;

    if (document.getElementById('firstname').value == '') {
        document.getElementById('firstname').style.borderColor = '#f00';
        document.getElementById('firstname_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('lastname').value == '') {
        document.getElementById('lastname').style.borderColor = '#f00';
        document.getElementById('lastname_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('city').value == '') {
        document.getElementById('city').style.borderColor = '#f00';
        document.getElementById('city_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('adress').value == '') {
        document.getElementById('adress').style.borderColor = '#f00';
        document.getElementById('adress_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('phone').value == '') {
        document.getElementById('phone').style.borderColor = '#f00';
        document.getElementById('phone_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('email').value == '') {
        document.getElementById('email').style.borderColor = '#f00';
        document.getElementById('email_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('username').value == '') {
        document.getElementById('username').style.borderColor = '#f00';
        document.getElementById('username_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('password').value == '') {
        document.getElementById('password').style.borderColor = '#f00';
        document.getElementById('password_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('password_ver').value == '') {
        document.getElementById('password_ver').style.borderColor = '#f00';
        document.getElementById('password_ver_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }
    if (document.getElementById('captcha').value == '') {
        document.getElementById('captcha').style.borderColor = '#f00';
        document.getElementById('captcha_error').innerHTML = 'Kötelező a mezőt kitölteni!';
        isValid = false;
    }


    return isValid;
}