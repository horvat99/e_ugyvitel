<?php

define("SALT1","wtSHSU890381IC4");
define("SALT2","4CITAcywut46a");
define("SITE","http://localhost/Ehesvagyok");
define("SECRET","gfhUi34xVbds23Qgk");
?>