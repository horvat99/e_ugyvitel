<?php

include('phpqrcode/qrlib.php');


QRcode::png('Horvát Tamás, 16218215');

