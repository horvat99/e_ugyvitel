<?php
// Create database connection
$db = mysqli_connect("localhost", "root", "6060", "Elhozom");

// Initialize message variable


// If upload button is clicked ...
if (isset($_POST['upload'])) {
    // Get image name
    $image = $_FILES['image']['name'];
    // Get text
    $foodname = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $type = $_POST['type'];


    // image file directory
    $target = "pictures/".basename($image);

    $sql = "INSERT INTO foods (food_name, description, price, type, image) VALUES ('$foodname','$description','$price','$type','$image')";
    // execute query
    mysqli_query($db, $sql);

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $msg = "Image uploaded successfully";
    }else{
        $msg = "Failed to upload image";
    }
}
$result = mysqli_query($db, "SELECT * FROM foods");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Image Upload</title>
    <style type="text/css">
        #content{
            width: 50%;
            margin: 20px auto;
            border: 1px solid #cbcbcb;
        }
        form{
            width: 50%;
            margin: 20px auto;
        }
        form div{
            margin-top: 5px;
        }
        #img_div{
            width: 80%;
            padding: 5px;
            margin: 15px auto;
            border: 1px solid #cbcbcb;
        }
        #img_div:after{
            content: "";
            display: block;
            clear: both;
        }
        img{
            float: left;
            margin: 5px;
            width: 100px;
            height: 100px;
        }
    </style>
</head>
<body>
<div id="content">
    <?php
    while ($row = mysqli_fetch_array($result)) {
        echo "<div id='img_div'>";
        echo "<img src='pictures/".$row['image']."' >";
        echo "<p>".$row['food_name']."<br>".$row['description']."</p>";
        echo "<p>".$row['postcode']."<br>".$row['price']."</p>";
        echo "<p>".$row['restaurant']."<br>".$row['type']."</p>";
        echo "</div>";
    }
    ?>
    <form method="POST" action="uploadfoods.php" enctype="multipart/form-data">
        <input type="hidden" name="size" value="1000000">
        <div>
            <input type="file" name="image">
        </div>

        name:<input type="text" name="name"><br>
        descrip:<input type="text" name="description"><br>
        price:<input type="text" name="price"><br>
        type:<input type="text" name="type"><br>

        <div>
            <button type="submit" name="upload">POST</button>
        </div>
    </form>
</div>
</body>
</html>