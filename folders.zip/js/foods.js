$(document).ready(function () {

    filter_data();

    function filter_data() {
        $('.filter_data').html('<div id="loading" style="" ></div>');
        var action = 'fetch_data';
        var postcode = get_filter('postcode');
        var type = get_filter('type');
        var restaurant = get_filter('restaurant');
        $.ajax({
            url: "fetch_data.php",
            method: "POST",
            data: {action: action, postcode: postcode, type: type, restaurant: restaurant},
            success: function (data) {
                $('.filter_data').html(data);
            }
        });
    }

    function get_filter(class_name) {
        var filter = [];
        $('.' + class_name + ':checked').each(function () {
            filter.push($(this).val());
        });
        return filter;
    }

    $('.common_selector').click(function () {
        filter_data();
    });

    load_cart_data(); //Kosar tartalma

    function load_cart_data() //Kosar tartalmanak betoltese
    {
        $.ajax({
            url: "fetch_cart.php",
            method: "POST",
            dataType: "json",
            success: function (data) {
                $('#cart_details').html(data.cart_details);
                $('.total_price').text(data.total_price);
            }
        });
    }

    $(document).on('click', '.add_to_cart', function () {
        var product_id = $(this).attr("id");
        var product_name = $('#name' + product_id + '').val();
        var product_price = $('#price' + product_id + '').val();
        var product_quantity = $('#quantity' + product_id).val();
        var action = "add";
        if (product_quantity > 0) {
            $.ajax({
                url: "action.php",
                method: "POST",
                data: {
                    product_id: product_id,
                    product_name: product_name,
                    product_price: product_price,
                    product_quantity: product_quantity,
                    action: action
                },
                success: function (data) {
                    load_cart_data();//Hozzáadódott az étel a kosárba
                }
            });
        }
    });

    $(document).on('click', '.delete', function () {
        var product_id = $(this).attr("id");
        var action = 'remove';


        $.ajax({
            url: "action.php",
            method: "POST",
            data: {product_id: product_id, action: action},
            success: function () {
                load_cart_data(); //Kosárból való törlés
            }
        })


    });

    $(document).on('click', '#clear_cart', function () {
        var action = 'empty';
        $.ajax({
            url: "action.php",
            method: "POST",
            data: {action: action},
            success: function () {
                load_cart_data(); //Kosár kiűrítése
            }
        });
    });

    $(document).ready(function () { //Kosar kinyitsa/csukasa
        $('#showcart').click(function () {
            $('#popover_content_wrapper').toggle();
        });
    });

});